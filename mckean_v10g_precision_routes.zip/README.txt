v8g: search fixed with live visible results, safe aliases, exact Enter match, and no-result feedback. Based on v8f default-fit.

Version: simple v9 all-rooms
Search now includes individual hotspots for all rooms, including D10, D11, D12, and individual classroom boxes instead of cluster-only search.


Version: simple v10g precision-routes
Routes are precision SVG polylines fitted to the user-marked hallway paths.
